export class Student 
{
    constructor(public id:number,public sname:string,public gender:string,public address:string,public email:string,public mobileno:string,public admissiondate:Date,public fees:number,public course_id:number,public image_path:string)
    {
        
    }
}
